﻿Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SqlClient

Partial Class CreateKommunity
    Inherits System.Web.UI.Page
    Protected Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        Dim conn As SqlConnection
        conn = New SqlConnection("Data Source=SQL5098.site4now.net;Initial Catalog=db_a84ebb_dbkommunitz;User Id=db_a84ebb_dbkommunitz_admin;Password=Project3957")
        conn.Open()
        Dim cmd As SqlCommand
        Dim Username As String = Session("Username").ToString
        Dim dt As String = DateTime.Now
        cmd = New SqlCommand("insert into tblKommunity(Kommunity_Name,Kommunity_Bio,Created_On,Username) values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + dt.ToString() + "','" + Username + "') ", conn)
        cmd.ExecuteNonQuery()
        Response.Redirect("Kommunity.aspx?Kommunity_Name=" + TextBox1.Text)
    End Sub
End Class
