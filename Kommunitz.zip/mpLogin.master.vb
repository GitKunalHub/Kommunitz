﻿Imports System.Data.OleDb
Imports System.Data
Imports System.Data.SqlClient

Partial Class mpLogin
    Inherits System.Web.UI.MasterPage

    Protected Sub btnLogin_ServerClick(sender As Object, e As EventArgs) Handles btnLogin.ServerClick
        Dim Username As String
        Dim Password As String
        Dim conn As SqlConnection
        conn = New SqlConnection("Data Source=SQL5098.site4now.net;Initial Catalog=db_a84ebb_dbkommunitz;User Id=db_a84ebb_dbkommunitz_admin;Password=Project3957")
        conn.Open()
        Try
            Dim da As SqlDataAdapter
            Dim ds As DataSet
            da = New SqlDataAdapter("select * from tblUsers where Username='" + txtEmail.Value + "' and Password='" + txtPassword.Value + "'", conn)
            ds = New DataSet
            da.Fill(ds)
            Username = ds.Tables(0).Rows(0)("Username").ToString()
            Password = ds.Tables(0).Rows(0)("Password").ToString()
            If Username <> "" Then
                Session("Username") = Username
            End If
            Response.Redirect("DemoHome2.aspx")
        Catch ex As Exception
            Try

                Dim da2 As SqlDataAdapter
                Dim ds2 As DataSet
                da2 = New SqlDataAdapter("select * from tblAdmin where Admin_Username='" & txtEmail.Value & "' and Password='" & txtPassword.Value & "'", conn)
                ds2 = New DataSet
                da2.Fill(ds2)

                Dim Admin As String = ds2.Tables(0).Rows(0)("Admin_Username").ToString()
                Dim admin_password As String = ds2.Tables(0).Rows(0)("Password").ToString()
                If Admin <> "" Then
                    Session("Username") = Admin
                    Response.Redirect("Admin.aspx")
                End If


            Catch ex2 As Exception
                MsgBox("Invalid Username or Password")

                Response.Redirect("login.aspx")
            End Try
        End Try




        Application("Login") = "Login"
        Response.Redirect("Demohome2.aspx")

        Response.Redirect("DemoHome2.aspx?Username=" + Username + "")
    End Sub

    
End Class

