<?php
/**
 * Cera template hooks for Jetpack.
 *
 * @package cera
 */

/**
 * Other hooks.
 *
 * @since 1.0.0
 */
add_filter( 'cera_is_mobile', 'jetpack_is_mobile', 10, 1 );
