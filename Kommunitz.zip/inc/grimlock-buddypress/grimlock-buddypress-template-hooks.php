<?php
/**
 * Cera template hooks for Grimlock for BuddyPress.
 *
 * @package cera
 */

add_action( 'cera_buddypress_actions_dropdown', 'cera_grimlock_buddypress_actions_dropdown', 100 );
add_action( 'cera_buddypress_actions_dropdown_profile', 'cera_grimlock_buddypress_actions_dropdown_profile', 100 );
