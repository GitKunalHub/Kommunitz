﻿
Partial Class Admin
    Inherits System.Web.UI.MasterPage
End Class

