﻿
Partial Class Upvote
    Inherits System.Web.UI.Page

End Class
