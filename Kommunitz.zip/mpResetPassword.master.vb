﻿Imports System.Data.OleDb
Imports System.Data

Partial Class mpResetPassword
    Inherits System.Web.UI.MasterPage

    Protected Sub login_btn_ServerClick(sender As Object, e As EventArgs) Handles login_btn.ServerClick

        Dim Mail As String
        Dim conn As OleDbConnection
        conn = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=K:\My Drive\Kommunitz\App_Data\dbKommunitz.accdb;Persist Security Info=True")
        conn.Open()
        Dim da As OleDbDataAdapter
        Dim ds As DataSet
        da = New OleDbDataAdapter("select * from tblUsers where Mail='" + txtEmail.Value + "'", conn)
        ds = New DataSet
        da.Fill(ds)
        Try
            Mail = ds.Tables(0).Rows(0)("Mail").ToString()


        Catch ex As Exception
            MsgBox("Invalid E-Mail ID")
            Response.Redirect("ResetPassword.aspx")
        End Try
        Application("Mail") = txtEmail.Value
        Response.Redirect("NewPassword.aspx")
        'Response.Redirect("NewPassword.aspx")
    End Sub
End Class

