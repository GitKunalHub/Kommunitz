﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Home
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        Dim Username As String = Session("Username")

        Dim conn As SqlConnection
        conn = New SqlConnection("Data Source=SQL5098.site4now.net;Initial Catalog=db_a84ebb_dbkommunitz;User Id=db_a84ebb_dbkommunitz_admin;Password=Project3957")
        conn.Open()

        Try

            Dim da2 As SqlDataAdapter
            Dim ds2 As DataSet
            da2 = New SqlDataAdapter("select * from tblAdmin where Admin_Username='" & Username & "'", conn)
            ds2 = New DataSet
            da2.Fill(ds2)

            Dim Admin As String = ds2.Tables(0).Rows(0)("Admin_Username").ToString()
            If Admin = Username Then
                Application("checked") = "true"
            End If
        Catch ex2 As Exception

        End Try


    End Sub

    Protected Sub Edit_ServerClick(sender As Object, e As EventArgs) Handles Edit.ServerClick
        Dim str As String = Session("Username")
        Response.Redirect("EditProfile.aspx?Username=" + str)
    End Sub
End Class

