﻿
Partial Class Register
    Inherits System.Web.UI.Page

End Class
