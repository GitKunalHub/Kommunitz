﻿
Partial Class SelectInterest
    Inherits System.Web.UI.Page

End Class
