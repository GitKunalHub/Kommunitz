﻿Imports System.Data
Imports System.Net
Imports System.Net.Mail
Imports System.Configuration
Imports System.Net.Configuration
Imports System.IO
Imports System.Data.SqlClient
Partial Class mpRegister
    Inherits System.Web.UI.MasterPage
    Protected Sub signup_Click(sender As Object, e As EventArgs) Handles signup.Click
        lblUsername.Text = name.Value
        Dim OTP As String
        Dim random As New Random

        OTP = random.Next(100000, 999999)
        lblOTP.Text = OTP
        Dim conn As SqlConnection
        conn = New SqlConnection("Data Source=SQL5098.site4now.net;Initial Catalog=db_a84ebb_dbkommunitz;User Id=db_a84ebb_dbkommunitz_admin;Password=Project3957")
        conn.Open()

        Dim cmd As SqlCommand

        cmd = New SqlCommand("insert into tblOTP values('" + email.Value + "','" + name.Value + "','" + pass.Value + "'," + OTP + ")", conn)
        Try
            Dim Smtp_Server As New SmtpClient
            Dim e_mail As New MailMessage()
            Smtp_Server.UseDefaultCredentials = False
            Smtp_Server.Credentials = New Net.NetworkCredential("Kommunitz1@gmail.com", "project3957")
            Smtp_Server.Port = 587
            Smtp_Server.EnableSsl = True
            Smtp_Server.Host = "smtp.gmail.com"

            Dim Filepath As String = "K:\My Drive\Komunitz Cera\EMail.html"
            Dim str As StreamReader = New StreamReader(Filepath)
            Dim MailText As String = str.ReadToEnd
            str.Close()

            MailText = MailText.Replace("[Username]", name.Value)
            MailText = MailText.Replace("[OTP]", OTP)
            e_mail.IsBodyHtml = True

            e_mail = New MailMessage()
            e_mail.From = New MailAddress("Kommunitz1@gmail.com")
            e_mail.To.Add(email.Value)
            e_mail.Subject = "Email Verification"
            e_mail.IsBodyHtml = True
            e_mail.Body = MailText
            Smtp_Server.Send(e_mail)

        Catch error_t As Exception
            MsgBox(error_t.ToString)
        End Try
        cmd.ExecuteNonQuery()
        Response.Redirect("Verification.aspx?Username=" + name.Value + "")
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Panel1.Visible = False
    End Sub
End Class

