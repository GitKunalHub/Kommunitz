﻿Imports System.Data
Imports System.Data.OleDb

Partial Class Post
    Inherits System.Web.UI.Page
    Dim HCid As HiddenField

    Protected Sub DataList1_ItemDataBound(sender As Object, e As DataListItemEventArgs) Handles DataList1.ItemDataBound
        If String.IsNullOrEmpty((CType(e.Item.FindControl("HiddenField1"), HiddenField)).Value) Then
            CType(e.Item.FindControl("PlaceHolder1"), PlaceHolder).Visible = False
        End If

        If String.IsNullOrEmpty((CType(e.Item.FindControl("HiddenField2"), HiddenField)).Value) Then
            CType(e.Item.FindControl("PlaceHolder2"), PlaceHolder).Visible = False
        End If

        If String.IsNullOrEmpty((CType(e.Item.FindControl("HiddenField3"), HiddenField)).Value) Then
            CType(e.Item.FindControl("PlaceHolder3"), PlaceHolder).Visible = False
        End If

        If e.Item.ItemType = ListItemType.Item OrElse e.Item.ItemType = ListItemType.AlternatingItem Then
            Dim lblDate As Label = CType(e.Item.FindControl("Posted_OnLabel"), Label)
            Dim dt As String
            lblDate.Text = lblDate.Text.Replace("/", "-")
            dt = CalCulateTime(lblDate.Text)
            CType(e.Item.FindControl("Posted_OnLabel"), Label).Text = dt.ToString()
        End If
    End Sub
    Public Sub DataList2_ItemCommand(source As Object, e As DataListCommandEventArgs) Handles DataList2.ItemCommand

        Dim conn As OleDbConnection

        conn = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=K:\My Drive\Kommunitz\App_Data\dbKommunitz.accdb;Persist Security Info=True")
        conn.Open()

        If e.CommandName = "Replies" And CType(e.Item.FindControl("Panel5"), Panel).Visible = False Then
            CType(e.Item.FindControl("Panel5"), Panel).Visible = True
        End If

        If e.CommandName = "Replies" And CType(e.Item.FindControl("Panel5"), Panel).Visible = True Then
            'CType(e.Item.FindControl("Panel5"), Panel).ViewStateMode = UI.ViewStateMode.Disabled
            'CType(e.Item.FindControl("Panel5"), Panel).ViewStateMode = UI.ViewStateMode.Disabled
            'Dim crid As String
            'crid = e.CommandArgument.ToString()
            'Session("crid") = crid
            CType(e.Item.FindControl("Panel5"), Panel).EnableViewState = True
        End If
        If e.CommandName = "Reply" Then
            Dim pnlReplyBox As Panel = CType(e.Item.FindControl("Panel1"), Panel)
            pnlReplyBox.Visible = False
            If IsPostBack Then
                CType(e.Item.FindControl("Panel1"), Panel).Visible = True
            End If
        End If

        If e.CommandName = "InComment" Then
            Dim cid As Integer = Val(e.CommandArgument.ToString())
            Dim cmd As OleDbCommand
            Dim cmd2 As OleDbCommand
            Dim pid As Integer = Val(Request.QueryString("Post_Ref_ID"))
            Dim Username As String = Session("Username").ToString
            Dim mid As Integer = Val(CType(e.Item.FindControl("HiddenField7"), HiddenField).Value)
            Dim cont As String = CType(e.Item.FindControl("commentrep"), TextBox).Text
            Dim time As String


            Dim rep As Integer = Val(CType(e.Item.FindControl("hiddenfield4"), HiddenField).Value)
            rep = rep + 1
            time = DateTime.Now

            cmd = New OleDbCommand("insert into tblComment(Comment_Content,Post_Ref_ID,Comment_Ref_ID,Username,Comment_Date,Main_ID) values('" & cont & "'," & pid & "," & cid & ",'" & Username & "','" & time.Replace(".", ":") & "'," & cid & ")", conn)

            cmd2 = New OleDbCommand("update tblComment set Replies=" & rep & " where Comment_ID=" & cid & "", conn)

            cmd.ExecuteNonQuery()


            cmd2.ExecuteNonQuery()
            'Response.Redirect("Post.aspx?Post_Ref_ID=" & pid)
        End If

        If e.CommandName = "Cancel" Then
            CType(e.Item.FindControl("Panel1"), Panel).Visible = False
        End If

    End Sub
    Protected Sub btnComment_ServerClick(sender As Object, e As EventArgs) Handles btnComment.ServerClick

        Dim conn As OleDbConnection

        conn = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=K:\My Drive\Kommunitz\App_Data\dbKommunitz.accdb;Persist Security Info=True")
        conn.Open()

        Try
            Dim cmd As OleDbCommand
            Dim id As String = Val(Request.QueryString("Post_Ref_ID"))
            Dim Username As String = Session("Username").ToString
            Dim cont As String = mycomment.Value
            Dim time As String

            time = DateTime.Now
            cmd = New OleDbCommand("insert into tblComment(Comment_Content,Post_Ref_ID,Username,Comment_Date) values ('" + cont + "'," + id + ",'" + Username + "','" + time.Replace(".", ":") + "')", conn)
            cmd.ExecuteNonQuery()

        Catch ex As Exception

        End Try

    End Sub


    Protected Sub DataList2_ItemCreated(sender As Object, e As DataListItemEventArgs) Handles DataList2.ItemCreated
        If e.Item.ItemType = ListItemType.AlternatingItem OrElse e.Item.ItemType = ListItemType.Item Then
            Dim inner As DataList = DirectCast(e.Item.FindControl("DataList3"), DataList)
            AddHandler inner.ItemCommand, AddressOf DataList3_ItemCommand

        End If


    End Sub

    Protected Sub DataList3_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataListCommandEventArgs)

        Dim conn As OleDbConnection

        conn = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=K:\My Drive\Kommunitz\App_Data\dbKommunitz.accdb;Persist Security Info=True")
        conn.Open()


        If e.CommandName = "InReply" Then
            CType(e.Item.FindControl("Panel4"), Panel).Visible = True
        End If

        If e.CommandName = "InCancel" Then
            CType(e.Item.FindControl("Panel4"), Panel).Visible = False
        End If

        If e.CommandName = "RepComment" Then
            Dim cid As Integer = Val(e.CommandArgument.ToString())
            Dim cmd As OleDbCommand
            Dim cmd2 As OleDbCommand
            Dim pid As Integer = Val(Request.QueryString("Post_Ref_ID"))
            Dim Username As String = Session("Username").ToString
            Dim cont As String = CType(e.Item.FindControl("repcomment"), TextBox).Text
            Dim time As String
            Dim mid As Integer = Val(CType(e.Item.FindControl("HiddenField6"), HiddenField).Value)
            Dim da As OleDbDataAdapter = New OleDbDataAdapter("select * from tblComment where Comment_ID=" & mid & "", conn)
            Dim ds As DataSet = New DataSet
            da.Fill(ds)
            Dim rep As Integer = Val(ds.Tables(0).Rows(0)("Replies").ToString())
            rep = rep + 1
            time = DateTime.Now
            cmd = New OleDbCommand("insert into tblComment(Comment_Content,Post_Ref_ID,Comment_Ref_ID,Username,Comment_Date,Main_ID) values ('" & cont & "'," & pid & "," & cid & ",'" & Username & "','" & time.Replace(".", ":") & "'," & mid & ")", conn)
            cmd2 = New OleDbCommand("update tblComment set Replies='" & rep & "'  where Comment_ID=" & mid & "", conn)

            cmd.ExecuteNonQuery()

            cmd2.ExecuteNonQuery()

        End If
    End Sub


    Protected Sub DataList2_ItemDataBound(sender As Object, e As DataListItemEventArgs) Handles DataList2.ItemDataBound

        If String.IsNullOrEmpty((CType(e.Item.FindControl("HiddenField4"), HiddenField)).Value) Then

            CType(e.Item.FindControl("Button1"), Button).Visible = False
            CType(e.Item.FindControl("Datalist3"), DataList).Visible = False
        End If

        If e.Item.ItemType = ListItemType.Item OrElse e.Item.ItemType = ListItemType.AlternatingItem Then
            Dim lblDate As Label = CType(e.Item.FindControl("Comment_DateLabel"), Label)
            Dim dt As String
            lblDate.Text = lblDate.Text.Replace("/", "-")
            dt = CalCulateTime(lblDate.Text)
            CType(e.Item.FindControl("Comment_DateLabel"), Label).Text = dt.ToString()
        End If
       
    End Sub
    Public Function CalCulateTime(ByVal postDate As DateTime) As String
        Dim message As String = ""
        Dim currentDate As DateTime = DateTime.Now
        Dim ctDate As String = currentDate
        ctDate = ctDate.Replace(":", ".")
        ctDate = ctDate.Replace("/", "-")
        Dim realDate As Date = ctDate
        Dim timegap As TimeSpan = realDate - postDate
        message = String.Concat("Posted on ", postDate.ToString("MMMM dd, yyyy"), " at ", postDate.ToString("hh:mm tt"))
        If timegap.Days > 365 Then
            message = String.Concat("", (((timegap.Days) / 30) / 12), " years ago")
        ElseIf timegap.Days > 62 Then
            Dim month As Integer = ((timegap.Days) / 30)
            message = String.Concat("", month, " months ago")
        ElseIf timegap.Days > 31 Then
            Dim month As Integer = ((timegap.Days) / 30)
            message = String.Concat("", month, " month ago")
        ElseIf timegap.Days > 1 Then
            message = String.Concat("", timegap.Days, " days ago")
        ElseIf timegap.Days = 1 Then
            message = "yesterday"
        ElseIf timegap.Hours >= 2 Then
            message = String.Concat("", timegap.Hours, " hours ago")
        ElseIf timegap.Hours >= 1 Then
            message = "an hour ago"
        ElseIf timegap.Minutes >= 60 Then
            message = "more than an hour ago"
        ElseIf timegap.Minutes >= 5 Then
            message = String.Concat("Posted ", timegap.Minutes, " minutes ago")
        ElseIf timegap.Minutes >= 1 Then
            message = "a few minutes ago"
        Else
            message = "less than a minute ago"
        End If

        Return message
    End Function

    Protected Sub dataList3_ItemDataBound(sender As Object, e As DataListItemEventArgs)
        If e.Item.ItemType = ListItemType.Item OrElse e.Item.ItemType = ListItemType.AlternatingItem Then
            Dim lblDate As Label = CType(e.Item.FindControl("InComment_Date"), Label)
            Dim dt As String
            lblDate.Text = lblDate.Text.Replace("/", "-")
            dt = CalCulateTime(lblDate.Text)
            CType(e.Item.FindControl("InComment_Date"), Label).Text = dt.ToString()
        End If

        Dim conn As OleDbConnection
        conn = New OleDbConnection("provider=microsoft.ace.oledb.12.0;data source=k:\my drive\komunitz cera\app_data\dbkommunitz.accdb")
        conn.Open()
        Dim pid As Integer = Val(CType(e.Item.FindControl("HiddenField8"), HiddenField).Value)
        Dim da As OleDbDataAdapter = New OleDbDataAdapter("select * from tblComment where Comment_ID=" & pid & "", conn)
        Dim ds As DataSet = New DataSet
        da.Fill(ds)
        Dim user As String = ds.Tables(0).Rows(0)("Username").ToString()
        CType(e.Item.FindControl("lblReceiver"), Label).Text = "Replying To" + user.ToString()

                'Try

        '    Dim kn As String = Request.QueryString("Post_Ref_ID")
        
        '    Dim un As String = ds.Tables(0).Rows(0)("Username").ToString()
        '    CType(e.Item.FindControl("lblReceiver"), Label).Text = un
        'Catch ex As Exception


        'End Try
    End Sub
End Class
