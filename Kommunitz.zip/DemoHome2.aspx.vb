﻿Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SqlClient
Partial Class DemoHome2
    Inherits System.Web.UI.Page

    Protected Sub DataList1_ItemCommand(source As Object, e As DataListCommandEventArgs) Handles DataList1.ItemCommand
        Dim conn As SqlConnection
        conn = New SqlConnection("Data Source=SQL5098.site4now.net;Initial Catalog=db_a84ebb_dbkommunitz;User Id=db_a84ebb_dbkommunitz_admin;Password=Project3957")
        conn.Open()
        If e.CommandName = "down" Then
            Dim vote As Integer = Val(CType(e.Item.FindControl("Vote"), Label).Text)
            vote = vote - 1
            Dim pid As Integer = Val(e.CommandArgument)
            Dim cmd As SqlCommand = New SqlCommand("update tblContent set Upvote=" & vote & " where Post_Ref_ID=" & pid & "", conn)
            cmd.ExecuteNonQuery()
            Response.Redirect("DemoHome2.aspx")
        End If

        If e.CommandName = "up" Then
            Dim vote As Integer = Val(CType(e.Item.FindControl("Vote"), Label).Text)
            vote = vote + 1
            Dim pid As Integer = Val(e.CommandArgument)
            Dim cmd As SqlCommand = New SqlCommand("update tblContent set Upvote=" & vote & " where Post_Ref_ID=" & pid & "", conn)
            cmd.ExecuteNonQuery()
            Response.Redirect("DemoHome2.aspx")
        End If
    End Sub


    Protected Sub DataList1_ItemDataBound(sender As Object, e As DataListItemEventArgs) Handles DataList1.ItemDataBound
        'If String.IsNullOrEmpty(((HiddenField)).Item.FindControl("HiddenField1")).Value)) Then
        If String.IsNullOrEmpty((CType(e.Item.FindControl("HiddenField1"), HiddenField)).Value) Then
            CType(e.Item.FindControl("PlaceHolder1"), PlaceHolder).Visible = False
        End If

        If String.IsNullOrEmpty((CType(e.Item.FindControl("HiddenField2"), HiddenField)).Value) Then
            CType(e.Item.FindControl("PlaceHolder2"), PlaceHolder).Visible = False
        End If

        If String.IsNullOrEmpty((CType(e.Item.FindControl("HiddenField3"), HiddenField)).Value) Then
            CType(e.Item.FindControl("PlaceHolder3"), PlaceHolder).Visible = False
        End If

        Dim btnClick As Button = CType(e.Item.FindControl("Button1"), Button)
        Dim ddl As DropDownList = CType(e.Item.FindControl("DropDownList1"), DropDownList)

        'Dim PostedOn As Label = CType(e.Item.FindControl("Posted_OnLabel"), Label)
        'If e.Item.ItemType = ListItemType.Item OrElse e.Item.ItemType = ListItemType.AlternatingItem Then
        '    Dim lblDate As Label = CType(e.Item.FindControl("Posted_OnLabel"), Label)
        '    Dim dt As String
        '    lblDate.Text = lblDate.Text.Replace("/", "-")
        '    dt = CalCulateTime(lblDate.Text)
        '    CType(e.Item.FindControl("Posted_OnLabel"), Label).Text = dt.ToString()
        'End If

        'Dim Admin_chkbox As CheckBox = TryCast(Me.Master.FindControl("Admin_chk"), CheckBox)

        'If Admin_chkbox.Checked = True Then
        '    CType(e.Item.FindControl("btnDelete"), Button).Visible = True
        'Else
        '    CType(e.Item.FindControl("btnDelete"), Button).Visible = False
        'End If
    End Sub
    'Public Function CalCulateTime(ByVal postDate As DateTime) As String
    '    Dim message As String = ""
    '    Dim currentDate As DateTime = DateTime.Now
    '    Dim ctDate As String = currentDate
    '    ctDate = ctDate.Replace(":", ".")
    '    ctDate = ctDate.Replace("/", "-")
    '    Dim realDate As Date = ctDate
    '    Dim timegap As TimeSpan = realDate - postDate
    '    message = String.Concat("Posted on ", postDate.ToString("MMMM dd, yyyy"), " at ", postDate.ToString("hh:mm tt"))
    '    If timegap.Days > 365 Then
    '        message = String.Concat("", (((timegap.Days) / 30) / 12), " years ago")
    '    ElseIf timegap.Days > 62 Then
    '        Dim month As Integer = ((timegap.Days) / 30)
    '        message = String.Concat("", month, " months ago")
    '    ElseIf timegap.Days > 31 Then
    '        Dim month As Integer = ((timegap.Days) / 30)
    '        message = String.Concat("", month, " month ago")
    '    ElseIf timegap.Days > 1 Then
    '        message = String.Concat("", timegap.Days, " days ago")
    '    ElseIf timegap.Days = 1 Then
    '        message = "yesterday"
    '    ElseIf timegap.Hours >= 2 Then
    '        message = String.Concat("", timegap.Hours, " hours ago")
    '    ElseIf timegap.Hours >= 1 Then
    '        message = "an hour ago"
    '    ElseIf timegap.Minutes >= 60 Then
    '        message = "more than an hour ago"
    '    ElseIf timegap.Minutes >= 5 Then
    '        message = String.Concat("Posted ", timegap.Minutes, " minutes ago")
    '    ElseIf timegap.Minutes >= 1 Then
    '        message = "a few minutes ago"
    '    Else
    '        message = "less than a minute ago"
    '    End If

    '    Return message
    'End Function

    Protected Sub lnkCreatePost_ServerClick(sender As Object, e As EventArgs) Handles lnkCreatePost.ServerClick
        DataList1.Visible = False
        pnlCreatePost.Visible = True
        TextBox1.Visible = False
    End Sub
    Protected Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click

        Dim username As String = Session("Username")
        'MsgBox(username)
        Dim conn As SqlConnection
        conn = New SqlConnection("Data Source=SQL5098.site4now.net;Initial Catalog=db_a84ebb_dbkommunitz;User Id=db_a84ebb_dbkommunitz_admin;Password=Project3957")
        conn.Open()
        Dim click As String
        click = DateTime.Now
        Dim str As String = DropDownList1.SelectedValue.ToString()


        If FileUpload2.HasFile = True And txtContent.Text <> "" And txtTitle.Text <> "" Then
            FileUpload2.SaveAs("k:\my drive\komunitz cera\user images\" + FileUpload2.FileName)
            Dim img As String = "user images\" + FileUpload2.FileName + ""
            Dim cmd As SqlCommand
            Dim vote As Integer = 0
            cmd = New SqlCommand("insert into tblcontent(content_title,content_text,content_image,kommunity_name,username,posted_on,upvote) values('" + txtTitle.Text + "','" + txtContent.Text + "','" + img + "','" + str + "','" + username + "','" + click.Replace(".", ":") + "'," & vote & ")", conn)
            If cmd.ExecuteNonQuery() Then
                Response.Redirect("DemoHome2.aspx")
            Else
                MsgBox("Error")
            End If
        Else
            Response.Write("please select a file or community")
        End If
    End Sub
End Class
