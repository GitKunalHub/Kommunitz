﻿Imports System.Data.OleDb
Imports System.Data
Imports System.Data.SqlClientss

Partial Class mpNewPassword
    Inherits System.Web.UI.MasterPage

    Protected Sub btnReset_ServerClick(sender As Object, e As EventArgs) Handles btnReset.ServerClick

        Dim MailCheck As String = Application("Mail")
        Dim npassword As String = new_password.Value
        Dim conn As OleDbConnection
        Dim cmd As OleDbCommand

        conn = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=K:\My Drive\Kommunitz\App_Data\dbKommunitz.accdb;Persist Security Info=True")
        conn.Open()
        cmd = New OleDbCommand("UPDATE tblUsers SET [Password] = '" & npassword.ToString & "' WHERE Mail = '" & MailCheck & "';", conn)
        cmd.ExecuteNonQuery()
        MsgBox("Updated Successfully")
        MsgBox(npassword)

    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Dim EMail As String = Request.QueryString("EMail")
        'Response.Write(EMail)
        'Label1.Text = EMail
        'new_password.Value = EMail
    End Sub
End Class

