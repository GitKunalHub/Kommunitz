﻿
Partial Class NewPassword
    Inherits System.Web.UI.Page

End Class
