﻿
Partial Class ResetPassword
    Inherits System.Web.UI.Page

End Class
