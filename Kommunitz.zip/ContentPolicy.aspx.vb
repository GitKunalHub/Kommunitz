﻿Partial Class ContentPolicy
    Inherits System.Web.UI.Page

End Class
